<?php
include '../connection.php';
$sem = $_SESSION['semester'];
$y = $_SESSION['year'];
$id = $_SESSION['id'];




?>

<html>

<head>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-base.min.js"></script>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-ui.min.js"></script>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-exports.min.js"></script>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-radar.min.js"></script>
  <link href="https://cdn.anychart.com/releases/v8/css/anychart-ui.min.css" type="text/css" rel="stylesheet">
  <link href="https://cdn.anychart.com/releases/v8/fonts/css/anychart-font.min.css" type="text/css" rel="stylesheet">
  <style type="text/css">
    html,
    body,
    #container {
      width: 100%;
      height: 100%;
      margin: 0;
      padding: 0;
    }
  </style>
</head>

<body>


  <div id="container"></div>


  <script>
    anychart.onDocumentReady(function() {
      // create data set on our data
      var dataSet = anychart.data.set([
        ['PLO1', 78],
        ['PLO2', 42],
        ['PLO3', 66, 92],
        ['PLO4', 58, 86],
        ['PLO5', 82, 86],
        ['PLO6', 66.45, 86],
        ['PLO7', 53, 86],
        ['PLO8', 0, 86],
        ['PLO9', 71, 86],
        ['PLO10', 4, 0],
        ['PLO11', 92, 0],
        ['PLO12', 13, 0],
        // ['Spirit', 158, 64, 196]
      ]);

      // map data for the first series, take x from the zero column and value from the first column of data set
      var data1 = dataSet.mapAs({
        x: 0,
        value: 1
      });
      // map data for the second series, take x from the zero column and value from the second column of data set
      var data2 = dataSet.mapAs({
        x: 0,
        value: 2
      });
      // map data for the third series, take x from the zero column and value from the third column of data set
      // var data3 = dataSet.mapAs({ x: 0, value: 3 });

      // create radar chart
      var chart = anychart.radar();

      // set chart title text settings
      chart.title(
        ' A specific Course And Student ID Wise Performance into a Semester: ' + '<?php echo "Summer"; ?>'
      );

      // set chart yScale settings
      chart.yScale().minimum(0).maximumGap(0).ticks().interval(50);

      // set xAxis labels settings
      chart.xAxis().labels().padding(5);

      // set chart legend settings
      chart.legend().align('center').enabled(true);


      // create first series with mapped data
      '<br>';
      var series1 = chart.line(data1).name('Md. Riyad Hossain');
      var series1 = chart.line(data1).name('1731407');
      series1.markers().enabled(true).type('circle').size(4);
      // create first series with mapped data
      var series2 = chart.line(data2).name('PLO Acheivement');
      series2.markers().enabled(true).type('circle').size(3);
      // create first series with mapped data
      // var series3 = chart.line(data3).name('Priest');
      // series3.markers().enabled(true).type('circle').size(3);

      // chart tooltip format
      chart.tooltip().format('Value: {%Value}');

      // set container id for the chart
      chart.container('container');
      chart.draw();
    });
  </script>
</body>

</html>