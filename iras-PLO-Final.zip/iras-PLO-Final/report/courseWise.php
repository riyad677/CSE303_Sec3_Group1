<?php
// $con = mysqli_connect('localhost','root','');
// mysqli_select_bd($con,'spm');
// $selcet = "SELECT * FROM course WHERE courseID = 'cse303'";////selected data from faculty page
// $query = mysqli_query($con,$select);
// $dataArr= Array();
// while ($row = $query->fetch_assoc()) {
//     $dataArr = $row;
// }
// echo "<script> var dataArray = ".json_encode($dataArr)."</script>";
?>

<html>
<head>
<style>
body{
    background:url('https://www.google.com/imgres?imgurl=https%3A%2F%2Fwww.pngitem.com%2Fpimgs%2Fm%2F513-5131515_website-background-design-illustration-hd-png-download.png&imgrefurl=https%3A%2F%2Fwww.pngitem.com%2Fmiddle%2FhwmxJbJ_website-background-design-illustration-hd-png-download%2F&tbnid=WDIZBDAfMo1CpM&vet=12ahUKEwihnr6grcPwAhVUk0sFHZsGDh4QMyhlegUIARDNAQ..i&docid=MdUD25U9TzXpBM&w=860&h=496&q=background%20image%20for%20website&ved=2ahUKEwihnr6grcPwAhVUk0sFHZsGDh4QMyhlegUIARDNAQ');
}
</style>

</head>
<body>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<div class="bg-info" align="center">
   <b>Enter Course ID</b>
   <select id="course_dropDown" class="form-select" name="select">
                <option selected > <i>Chart List </i></option>
                <option value="CSC101"> CSC101</option>
                <option value="CSC101"> CSC101L</option>
                <option value="CSC101"> CSE203</option>
                <option value="CSC101"> CSE203L</option>
                <option value="CSC101"> CSE201</option>
                <option value="CSC101"> CSE104</option>
                <option value="CSC101"> CSE104L</option>
                <option value="CSC101"> CSE204</option>
                <option value="CSC101"> CSE204L</option>
                <option value="CSC101"> CSE213</option>
                <option value="CSC101"> CSE216</option>
                <option value="CSC101"> CSE216L</option>
                <option value="CSC101"> CSE210</option>
                <option value="CSC101"> CSE210L</option>
                

    </select><br><br>
   <form action="courseWise.php" method="POST">
   <select id="course_dropDown" class="form-select" name="select">
                <option selected disabled> <i>Chart List </i></option>
                <option value="LineChart"> LineChart</option>
                <option value="BarChart"> BarChart</option>
                <option value="RadarChart"> RadarChart</option>

    </select>
    <!-- <script>
    document.getElementsByName('select')[0].value = '<?php echo $_POST['select']; ?>'
</script> -->
    <input type="submit" name="submit" onclick="drawChart()"> 
    </form>
    <?php
    $structure1 = $_POST['select'];
    ?>
</div>
<!-- <script>
        $(document).ready(function() {
            $("#course_dropDown").on('change', function() {
                
                $(".data").hide();
                //var courseSelectedNode = document.getElementById("course_dropDown");
                var courseSelected = document.getElementById("course_dropDown").value;
                $(".data").attr("id", courseSelected);
                $("#" + $(this).val()).fadeIn(700);
            }).change();
        });

        $(function() {
            $(".but").on("click", function(e) {
                e.preventDefault();
                $(".<?php echo $content; ?>").hide();
                $("#" + this.id + "div").fadeIn(700);
            });
        });
    
</script> -->
<script type="text/javascript">
    var my_2d = [["PLO1","89"],["PLO2","69"],["PLO3","77"],["PLO4","57"]]  //,["PLO4","57"],["ASP","70"]]
      google.charts.load('current', {'packages':['corechart']});

      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Instructor');
        data.addColumn('number', 'PLO-Achievement');
        for(i = 0; i < my_2d.length; i++)
    data.addRow([my_2d[i][0], parseInt(my_2d[i][1])]);
        // Set chart options
        var options = {'title':'Course Wise Instructor Performance',
                       'width':600,
                       'height':500,
			   is3D:true,};


        var chart = new google.visualization.<?php echo $structure1 ;?>(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
	
</script>

 <section>
    <div class="container">
        <div class = "row">
            <div class="col-lg-6 px-5 mr-3" align="center">
               <div id="chart_div"></div>
            </div>
            <div class="col-lg-6 px-5 mr-3" align="center">
            <textarea type=text name='sugession' placeholder="suggestions about improving students’ performance"></textarea>
            </div>
        </div>
    </div>
</section>


    
</body>
</html>