


<?php
        session_start();
        $con = mysqli_connect('localhost','root');
        mysqli_select_db($con, 'test');
    $ycpArr = array();
    $ycpArr1 = array();
    $i=0;
    $q = "SELECT programID, COUNT(s.studentID) AS total FROM student AS s GROUP BY programID";
    $query = mysqli_query($con, $q);
    while($travese = $query->fetch_assoc()){
        // array_push($ycpArr, $travese['total']);
        // array_push($ycpArr1, $travese['programID']);
        $ycpArr[$i][0]=$travese['programID'];
        $ycpArr[$i][1]=$travese['total'];
        $i++;
        
    }
?>


<html>
<head>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-base.min.js"></script>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-ui.min.js"></script>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-exports.min.js"></script>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-radar.min.js"></script>
  <link href="https://cdn.anychart.com/releases/v8/css/anychart-ui.min.css" type="text/css" rel="stylesheet">
  <link href="https://cdn.anychart.com/releases/v8/fonts/css/anychart-font.min.css" type="text/css" rel="stylesheet">
  <style type="text/css">
    html,
      body,
      #container {
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
      }
  
</style>
</head>
<body>
    
    <section>
    <div class="container">
        <div class = "row">
            <div class="col-lg-6 px-5 mr-3" align="center">
            <div id="container"></div>
            </div>
            <div class="col-lg-6 px-5 mr-3" align="center">
            <textarea type=text name='sugession' placeholder="suggestions about improving students’ performance"></textarea>
            </div>
        </div>
    </div>
</section>

    <?php echo json_encode($ycpArr); ?>

    <script type="text/javascript">

    // var obj = <?php echo json_encode($ycpArr); ?>;
    // var obj4 = <?php echo json_encode($ycpArr1); ?>;

    anychart.onDocumentReady(function () {
        // create data set on our data
        var dataSet = anychart.data.set([
        ['PLO1', 0],
        ['PLO2', 82],
        ['PLO3', 66],
        ['PLO4', 0],
        ['PLO5', 0],
        ['PLO6', 0],
        ['PLO7', 0],
        ['PLO8', 0],
        ['PLO9', 71],
        ['PLO10', 69],
        ['PLO11', 0],
        ['PLO12', 0],
        // ['Spirit', 158, 64, 196]
        ]);

        // map data for the first series, take x from the zero column and value from the first column of data set
        var data1 = dataSet.mapAs({ x: 0, value: 1 });
        // map data for the second series, take x from the zero column and value from the second column of data set
        var data2 = dataSet.mapAs({ x: 0, value: 2 });
        // map data for the third series, take x from the zero column and value from the third column of data set
        // var data3 = dataSet.mapAs({ x: 0, value: 3 });

        // create radar chart
        var chart = anychart.radar();

        // set chart title text settings
        chart.title(
        'Student Id Wise Performance into a Semester: '+'<?php echo "Summer"; ?>'
        );

        // set chart yScale settings
        chart.yScale().minimum(0).maximumGap(0).ticks().interval(50);

        // set xAxis labels settings
        chart.xAxis().labels().padding(5);

        // set chart legend settings
        chart.legend().align('center').enabled(true);

        
        // create first series with mapped data
        var series1 = chart.line(data1).name('Md. Riyad Hossain');
        var series1 = chart.line(data1).name('1731407');
        series1.markers().enabled(true).type('circle').size(4);
        // create first series with mapped data
        var series2 = chart.line(data2).name('Acutal Acheivement');
        series2.markers().enabled(true).type('circle').size(3);
        // create first series with mapped data
        // var series3 = chart.line(data3).name('Priest');
        // series3.markers().enabled(true).type('circle').size(3);

        // chart tooltip format
        chart.tooltip().format('Value: {%Value}');

        // set container id for the chart
        chart.container('container');
        chart.draw();
    });

    </script>

   
</body>
</html>