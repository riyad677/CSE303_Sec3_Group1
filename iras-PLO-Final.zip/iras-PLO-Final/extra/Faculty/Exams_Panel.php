<?php
session_start();

$_SESSION['issetCO'] = false;

if ($_SESSION['issetCO']) {
    $content = "content2";
    $contentLoader = "contentLoader2";
} else {
    $content = "content1";
    $contentLoader = "contentLoader1";
}
//$togglerID = "option_toggler1";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IRAS-PLO</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="facultyStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script> -->
    <!-- <script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script> -->


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/repeater.js"></script>


</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">Exams</a>

        <p>&nbsp&nbsp&nbsp</p>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="data">

                <a href="dashboard_Faculty.php"><button type="button" class="btn btn-success">Main Page</button></a>
                <a href="makeQuestions.php"><button type="button" class="btn btn-success">Make questions</button></a>
                <a href="../index.php"><button type="button" class="btn btn-success">CQI Reports</button></a>

            </div>

            <ul class="navbar-nav ml-auto">
                <div class="navbar-text ml-lg-3">
                    <a href="../../index.php" class="btn btn-primary text-white shadow">Sign out</a>
                </div>
            </ul>
        </div>
    </nav>

    <h1>This is Mr. Faculty of the Engineering department!</h1>
    <!-- <button onclick="counterIncrement()">This is for test</button> -->


    

    <!-- <script src="../../scripts/jquery.min.js"></script> -->
    <script>
        $(document).ready(function() {
            var x = 2; //initlal text box count
            var max_fields = 11; //maximum input boxes allowed
            var wrapper = $(".input_fields_wrap"); //Fields wrapper
            var add_button = $(".add_field_button"); //Add button ID


            var b = '"><div class="col-md-11"><label for="course_description">Write the course description below in details. Note: The following CO will be saved as CO- ';
            var c = '<p id="CLO_current_number"></p></label><textarea name="mytext[]" id="course_description" required></textarea>';
            var d = '</div><button class = "remove_field" align="right" id="closer"></button></div>';


            $(add_button).click(function(e) { //on add input button click
                e.preventDefault();

                if (x <= max_fields) { //max input box allowed

                    //text box increment

                    var PLOArr = []

                    for (var i = 1; i <= 12; i++) {

                        //PLOArr.push('&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="checkbox" id = "' + x + i + '"name = "PLO[]">');
                        PLOArr.push('&nbsp&nbsp<input type="checkbox" id = "' + x + i + '"name = "PLO_CO' + x + '[]" value = "PLO-' + i + '">');
                        PLOArr.push('<label for = "' + x + i + '">&nbspPLO-' + i + '</label>');

                    }

                    var a = '<div class="row CLO_Div" id = "list' + x;

                    $(wrapper).append(a + b + x + c + PLOArr.join("") + d);
                    //$(wrapper).append(x);

                    x++;
                }
            });


            $(wrapper).on("click", ".remove_field", function(e) { //user click on remove text
                e.preventDefault();

                if (x > 3) {
                    var newItem = document.createElement('BUTTON');
                    newItem.id = "closer";
                    newItem.className = "remove_field";


                    //var newX = x - 2;
                    str = "list" + (x - 2).toString();
                    var list = document.getElementById(str);

                    list.insertBefore(newItem, list.childNodes[1]);
                }

                $(this).parent('div').remove();


                if (x >= 2) {
                    x--;
                } else {
                    x = 1;
                }
            })
        });


        $(document).ready(function() {
            $("#course_dropDown").on('change', function() {
                
                $(".data").hide();
                //var courseSelectedNode = document.getElementById("course_dropDown");
                var courseSelected = document.getElementById("course_dropDown").value;
                $(".data").attr("id", courseSelected);
                $("#" + $(this).val()).fadeIn(700);
            }).change();
        });

        $(function() {
            $(".but").on("click", function(e) {
                e.preventDefault();
                $(".<?php echo $content; ?>").hide();
                $("#" + this.id + "div").fadeIn(700);
            });
        });
    </script>
    <!-- <script src="../../scripts/graph.Loader.js"></script> -->
</body>

</html>