<?php
    include '../../connection.php';
    
    $c =  $_SESSION['c'];
    $plo1 = $_POST['plo1'];
    $plo2 = $_POST['plo2'];
    $plo3 = $_POST['plo3'];
    $plo4 = $_POST['plo4'];
    $insert1 = "INSERT INTO ploinitialmapping(ploID,courseID) values('$plo1','$c')";
    $insert2 = "INSERT INTO ploinitialmapping(ploID,courseID) values('$plo2','$c')";
    $insert3 = "INSERT INTO ploinitialmapping(ploID,courseID) values('$plo3','$c')";
    $insert4 = "INSERT INTO ploinitialmapping(ploID,courseID) values('$plo4','$c')";
    mysqli_query($con, $insert1);
    mysqli_query($con, $insert2);
    mysqli_query($con, $insert3);
    mysqli_query($con, $insert4);
?>

<script>
        alert("Successfully Done....!!!");
        window.location = 'dashboard_Head.php';
    </script>