<?php
    include '../../connection.php';

    $fname =  $_POST['fname'];
    $lname =  $_POST['lname'];
    $sid =  $_POST['sid'];
    $sem =  $_POST['sem'];
    $year =  $_POST['year'];
    $email = $_POST['email'];
    $contact = $_POST['phoneNo'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $program = $_POST['program'];
    
    
    
    $insert = "INSERT INTO student(fname,lname,studentID, semester,	year,	email,	contact,	dob,  gender,	programID) 
                values('$fname','$lname','$sid','$sem','$year','$email','$contact','$dob','$gender','$program')";
	mysqli_query($con, $insert);

?>
<script>
        alert("Successfully Done....!!!");
        window.location = 'uadmin.php';
    </script>