<?php
    include '../../connection.php';
    $name =  $_POST['name'];
    $id =  $_POST['fid'];
    $email = $_POST['email'];
    $contact = $_POST['phoneNo'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $dept = $_POST['dept'];
    
    

    $insert = "INSERT INTO faculty(facultyID, facultyName, dob, gender, email, contactNo, deptShortName) 
                    values('$id', '$name','$dob', '$gender','$email','$contact','$dept')";
    mysqli_query($con, $insert);
?>
    <script>
        alert("Successfully Done....!!!");
        window.location = 'uadmin.php';
    </script>
