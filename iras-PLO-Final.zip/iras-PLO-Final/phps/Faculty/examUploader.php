<?php
include '../../connection.php';

$id = $_SESSION['id'];

$questionArr = $_POST['questionDescription'];
$marks = $_POST['total'];
$sampleAns = $_POST['sampleans'];
$co = $_POST['co'];
$hours = $_POST['hours'];
$minutes = $_POST['minutes'];
$dueration = $hours.": ".$minutes;
$type = $_POST['type'];
$t1 = substr($type,0,1);
$time = $_POST['time'];
$date = $_POST['date'];
$enrollmentID = $_SESSION['course'];

$a = "SELECT count(assessmentID) AS t FROM assessment WHERE nameOfAss = '$type' AND enrollmentID ='$enrollmentID' GROUP BY nameOfAss";
$qqq = mysqli_query($con, $a);
$ttt = mysqli_fetch_array($qqq);
$c = isset($ttt['t']) ? $ttt['t'] : 0;
$c = (int)$c + 1;

$assessmentID = $_SESSION['course']."_".$t1.$c ;
$q;

// echo "<br>The Questions Are: <br><br><br>";
$totalMarks = 0;
if (!empty($questionArr)) {
    for ($y = 0; $y < count($questionArr); $y++) {
        $totalMarks += (int)$marks[$y];
    }

    $insert = "INSERT INTO assessment (assessmentID, totalMarks, enrollmentID,nameOfAss, time, date, duration) 
                        VALUES ('$assessmentID', '$totalMarks', '$enrollmentID', '$type', '$time', '$date', '$dueration')";
    mysqli_query($con, $insert);
    $y =0 ;
    $q; $qu; $ma; $ans; $cccccc;
    while($y < count($questionArr)) {
        echo "Question Details: ";
        echo $questionArr[$y];
        $qu =  $questionArr[$y];
        echo "<br>Course Outcome: " . $co[$y];
        $cccccc = $co[$y]."_".$enrollmentID;;
        echo "<br>";
        echo "Marks: " . $marks[$y];
        $ma = $marks[$y];
        echo "<br>";
        echo "Sample Answer: " . $sampleAns[$y];
        $ans =  $sampleAns[$y];
        echo "<br> <br>";
        $q = $assessmentID."_".($y+1);
        $totalMarks += (int)$marks[$y];
        
        // $iii = "INSERT INTO question(quesID, quesDetails, marks, sampleAns, facultyID, coID, assessmentID) 
        //             VALUES ('$q', '$qu', '$ma', '$ans', '$id', '$cccccc', '$assessmentID')";
        // mysqli_query($con, $iii);
        $insert = "INSERT INTO question (quesID, details, mark,sampleAns, facultyID, coID, assessmentID) 
                        VALUES ('$q', '$qu', '$ma', '$ans', '$id', '$cccccc', '$assessmentID')";
        mysqli_query($con, $insert);
        $y++;
    }

} else {
    echo "NULL";
}
?>

<script>
        alert("Successfully Done....!!!");
        window.location = 'facultyCourseInformation.php';
    </script>